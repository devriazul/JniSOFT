<?php
include_once ('../../vendor/autoload.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
	//if not logged in redirect him
	if (!isset($_SESSION['user_roll'])) {
		header("Location: ../home/login.php");
	}
	use Dompdf\Dompdf;

	$settings = new App\settings\Settings();

	//get user role from session
	$user_role = $_SESSION['user_roll'];
	$operation = 'tabulation-print';

	//check access permission for this user
	if (!$settings->get_user_permission($user_role, $operation)) {
	   header("Location: ../home/403.php");
	   die();
	}

	$str = '<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		@font-face {
		    font-family: f1;
		    src: url(fonts/f1.ttf);
		}
		@font-face {
		    font-family: f2;
		    src: url(fonts/f2.ttf);
		}
		@font-face {
		    font-family: f3;
		    src: url(fonts/f3.otf);
		}
		@font-face {
		    font-family: f4;
		    src: url(fonts/f4.ttf);
		}
		@font-face {
		    font-family: f5;
		    src: url(fonts/f5.ttf);
		}
		@font-face {
		    font-family: f6;
		    src: url(fonts/f6.ttf);
		}
		body {
			min-height: 500px;
			background: url(frame3.png);
    		background-repeat: no-repeat;
			width: 1050px;
		}
		.head {
			line-height: 30px;
		}
		.logo {
			position: absolute;
			left: 100px;
			top: 60px;
		}
		.head-title {
			text-align: center;
			padding-top: 25px;
		}
		.name {
			font-size: 36px;
			color: #0072bc;
			font-family: f1;
		}
		.address{
			font-size: 15px;
			font-family: f2;
		}
		.title {
			font-family: f4;
			font-size: 22px;
			color: #00aeef;
		}

		.text {
			margin-left: 85px;
			margin-right: 80px;
			line-height: 30px;
		}
		.serial {
			/*font-family: f3;*/
			font-size: 12;
		}
		.text-body{
			font-family: f5;
			font-size: 14;
		}

		.footer {
			padding-left: 85px;
			margin-top: 20px;
		}
		.date {
			/*font-family: f3; */
			font-size: 12;
			float: left;
			width: 55%;
			padding-top: 30px;
		}
		.sign{
			font-family: f6;
			font-size: 14;
			width: 45%;
			float: left;
			text-align: center;
		}
		.sign small {
			font-family: f2;
			font-size: 11;
		}


	</style>
</head>
<body>
				
	<div class="container">
		<div class="head">
			<div class="logo2">
			&nbsp;<img src="logo.png" class="logo" width="80" height="80">
			</div>
			<div class="head-title">
				<div class="name">
					SAIC NURSING COLLEGE
				</div>
				<div class="address">
					Mirpur, Dhaka
				</div>
				<div class="title">
					TESTIMONIAL
				</div>
			</div>
			
		</div>

		<div class="text">
			<div class="serial">
				SL No. :
			</div>
			<div class="text-body">
				This is to certify Mr. /Miss ........................................................................................................................................................................ <br>
				Son/Daughter of Mr ................................................................................. Mrs ......................................................................................... <br>
				Date of Birth ..................................Reg. No.............................Session...................................Examination Roll No ................................ <br>
				Permanent Address ..................................................................................... P.O......................................................................................... <br>
				PS......................................................................................District.............................................................., Bangladesh was a student of <br>
				the ..................................................................................................................................From ...................................to.............................. <br>
				He/She passed the Diploma in Nursing Science & Midwifery held in ................................ obtaining CGPA .............................. Scale 4. <br>
				To the best  of my knowledge, during the period of his/her study at this institution, he/she  bear 
				a good moral character and did not take <br>
				 part in any subversive activity of the state.
				<br>I wish his/her every success in life.  
			</div>
		</div>

		<div class="footer">
			<div class="date">
				Date:.........................	
			</div>
			<div class="sign">
				Principal <br>
				<small>Saic Nursing College, Dhaka</small>
			</div>
		</div>
	</div>
</body>
</html>';


	if (true) {
		$dompdf = new Dompdf();
		$dompdf->loadHtml($str);
		$dompdf->setPaper('A4', 'landscape');
		$dompdf->render();
		$dompdf->stream('file.pdf', array( 'Attachment'=>0 ) );
	}



?>